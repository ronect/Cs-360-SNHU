package com.example.finaleventtrackerappbyronnieector;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * SmsPermissionActivity lets a new user decide whether to enable SMS reminders.
 * The app continues to work even if the user denies or skips SMS permission.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "EventTrackerPrefs";
    private static final String SMS_CHOICE_MADE = "sms_choice_made";

    private TextView smsStatusText;
    private Button enableSmsButton;
    private Button skipSmsButton;

    private int currentUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        smsStatusText = findViewById(R.id.sms_status_text);
        enableSmsButton = findViewById(R.id.enable_sms_button);
        skipSmsButton = findViewById(R.id.skip_sms_button);

        enableSmsButton.setOnClickListener(view -> checkSmsPermission());

        skipSmsButton.setOnClickListener(view -> {
            saveSmsChoice();
            openEventScreen();
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            saveSmsChoice();
            openEventScreen();

        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            saveSmsChoice();
            openEventScreen();
        }
    }

    private void saveSmsChoice() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        preferences.edit().putBoolean(SMS_CHOICE_MADE, true).apply();
    }

    private void openEventScreen() {
        Intent intent = new Intent(SmsPermissionActivity.this, EventActivity.class);
        intent.putExtra("USER_ID", currentUserId);
        startActivity(intent);
        finish();
    }
}