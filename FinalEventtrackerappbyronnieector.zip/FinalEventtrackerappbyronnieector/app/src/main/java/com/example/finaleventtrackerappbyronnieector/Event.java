package com.example.finaleventtrackerappbyronnieector;

/**
 * Model class that represents one event item.
 */
public class Event {

    public int id;
    public String name;
    public String date;
    public String time;

    public Event(int id, String name, String date, String time) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
    }
}