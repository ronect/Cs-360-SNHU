package com.example.finaleventtrackerappbyronnieector;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * EventActivity allows the logged-in user to add, view, update, and delete events.
 * Each user only sees their own events because events are saved with a user ID.
 */
public class EventActivity extends AppCompatActivity {

    // Emulator test number. Change this if your emulator number is different.
    private static final String TEST_PHONE_NUMBER = "5554";

    private DatabaseHelper databaseHelper;
    private RecyclerView eventsRecyclerView;
    private EventAdapter eventAdapter;
    private ArrayList<Event> eventList;

    private EditText eventNameEditText;
    private EditText eventDateEditText;
    private EditText eventTimeEditText;

    private Button addEventButton;
    private Button updateEventButton;

    private int selectedEventId = -1;
    private int currentUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        // Gets the logged-in user's ID from MainActivity or SmsPermissionActivity.
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        if (currentUserId == -1) {
            Toast.makeText(this, "User error. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        eventsRecyclerView = findViewById(R.id.events_recycler_view);
        eventNameEditText = findViewById(R.id.event_name_edit_text);
        eventDateEditText = findViewById(R.id.event_date_edit_text);
        eventTimeEditText = findViewById(R.id.event_time_edit_text);
        addEventButton = findViewById(R.id.add_event_button);
        updateEventButton = findViewById(R.id.update_event_button);

        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        eventDateEditText.setFocusable(false);
        eventDateEditText.setClickable(true);
        eventDateEditText.setOnClickListener(view -> showDatePicker());

        eventTimeEditText.setFocusable(false);
        eventTimeEditText.setClickable(true);
        eventTimeEditText.setOnClickListener(view -> showTimePicker());

        addEventButton.setOnClickListener(view -> addEvent());
        updateEventButton.setOnClickListener(view -> updateEvent());

        loadEvents();
    }

    private void addEvent() {
        String name = eventNameEditText.getText().toString().trim();
        String date = eventDateEditText.getText().toString().trim();
        String time = eventTimeEditText.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill in all event fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Saves this event only for the currently logged-in user.
        databaseHelper.addEvent(currentUserId, name, date, time);

        // Sends optional SMS reminder only if permission was granted.
        sendEventSms(name, date, time);

        clearFields();
        loadEvents();

        Toast.makeText(this, "Event added.", Toast.LENGTH_SHORT).show();
    }

    private void updateEvent() {
        if (selectedEventId == -1) {
            Toast.makeText(this, "Tap an event first to select it.", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = eventNameEditText.getText().toString().trim();
        String date = eventDateEditText.getText().toString().trim();
        String time = eventTimeEditText.getText().toString().trim();

        if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill in all event fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        databaseHelper.updateEvent(selectedEventId, currentUserId, name, date, time);

        sendEventSms(name, date, time);

        selectedEventId = -1;
        clearFields();
        loadEvents();

        Toast.makeText(this, "Event updated.", Toast.LENGTH_SHORT).show();
    }

    private void sendEventSms(String eventName, String eventDate, String eventTime) {
        // If the user denied SMS permission, the app still works without sending a text.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String message = "Reminder: Your event \"" + eventName + "\" is coming up on "
                + eventDate + " at " + eventTime + ".";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(TEST_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(this, "SMS reminder sent.", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "SMS reminder could not be sent.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadEvents() {
        eventList = new ArrayList<>();

        // Only loads events that belong to the logged-in user.
        Cursor cursor = databaseHelper.getEventsForUser(currentUserId);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String time = cursor.getString(3);

            eventList.add(new Event(id, name, date, time));
        }

        cursor.close();

        eventAdapter = new EventAdapter(
                eventList,

                event -> {
                    selectedEventId = event.id;
                    eventNameEditText.setText(event.name);
                    eventDateEditText.setText(event.date);
                    eventTimeEditText.setText(event.time);

                    Toast.makeText(this, "Event selected. Edit the fields and press Update Event.", Toast.LENGTH_SHORT).show();
                },

                eventId -> {
                    databaseHelper.deleteEvent(eventId, currentUserId);
                    selectedEventId = -1;
                    clearFields();
                    loadEvents();

                    Toast.makeText(this, "Event deleted.", Toast.LENGTH_SHORT).show();
                }
        );

        eventsRecyclerView.setAdapter(eventAdapter);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String date = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                    eventDateEditText.setText(date);
                },
                year,
                month,
                day
        );

        datePickerDialog.show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();

        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, selectedHour, selectedMinute) -> {
                    String amPm = "AM";
                    int displayHour = selectedHour;

                    if (selectedHour >= 12) {
                        amPm = "PM";

                        if (selectedHour > 12) {
                            displayHour -= 12;
                        }
                    }

                    if (displayHour == 0) {
                        displayHour = 12;
                    }

                    String time = String.format("%d:%02d %s", displayHour, selectedMinute, amPm);
                    eventTimeEditText.setText(time);
                },
                hour,
                minute,
                false
        );

        timePickerDialog.show();
    }

    private void clearFields() {
        eventNameEditText.setText("");
        eventDateEditText.setText("");
        eventTimeEditText.setText("");
    }
}