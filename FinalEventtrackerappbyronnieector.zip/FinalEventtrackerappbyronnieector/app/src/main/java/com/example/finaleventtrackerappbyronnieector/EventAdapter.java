package com.example.finaleventtrackerappbyronnieector;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Adapter class that connects event data to the RecyclerView.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private ArrayList<Event> eventList;
    private OnEventClickListener eventClickListener;
    private OnDeleteClickListener deleteClickListener;

    public interface OnEventClickListener {
        void onEventClick(Event event);
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(int eventId);
    }

    public EventAdapter(ArrayList<Event> eventList,
                        OnEventClickListener eventClickListener,
                        OnDeleteClickListener deleteClickListener) {
        this.eventList = eventList;
        this.eventClickListener = eventClickListener;
        this.deleteClickListener = deleteClickListener;
    }

    /**
     * Holds the views for each row in the RecyclerView.
     */
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView dateText;
        TextView timeText;
        Button deleteButton;

        public EventViewHolder(View itemView) {
            super(itemView);

            nameText = itemView.findViewById(R.id.row_event_name);
            dateText = itemView.findViewById(R.id.row_event_date);
            timeText = itemView.findViewById(R.id.row_event_time);
            deleteButton = itemView.findViewById(R.id.row_delete_button);
        }
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate one event row layout.
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_row, parent, false);

        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        // Display event information in the row.
        holder.nameText.setText(event.name);
        holder.dateText.setText(event.date);
        holder.timeText.setText(event.time);

        // Selects the event when the row is tapped.
        holder.itemView.setOnClickListener(view -> eventClickListener.onEventClick(event));

        // Deletes the event when the delete button is tapped.
        holder.deleteButton.setOnClickListener(view -> deleteClickListener.onDeleteClick(event.id));
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }
}