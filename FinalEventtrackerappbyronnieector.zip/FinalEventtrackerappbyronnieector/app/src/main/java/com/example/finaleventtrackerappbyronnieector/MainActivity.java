package com.example.finaleventtrackerappbyronnieector;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity handles user login and account creation.
 * New users are sent to the SMS permission screen.
 * Existing users go directly to their own event list.
 */
public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(view -> loginUser());
        createAccountButton.setOnClickListener(view -> createAccount());
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean loginSuccess = databaseHelper.checkUser(username, password);

        if (loginSuccess) {
            int userId = databaseHelper.getUserId(username, password);

            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, EventActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);

        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkUsernameExists(username)) {
            Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean accountCreated = databaseHelper.addUser(username, password);

        if (accountCreated) {
            int userId = databaseHelper.getUserId(username, password);

            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, SmsPermissionActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);

        } else {
            Toast.makeText(this, "Account could not be created.", Toast.LENGTH_SHORT).show();
        }
    }
}