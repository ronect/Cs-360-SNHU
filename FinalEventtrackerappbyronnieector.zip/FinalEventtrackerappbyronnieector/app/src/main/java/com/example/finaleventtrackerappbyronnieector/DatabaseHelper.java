package com.example.finaleventtrackerappbyronnieector;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper manages the SQLite database for users and events.
 * Events are connected to users using the user_id column.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EventTracker.db";

    // Increase database version so Android rebuilds the database.
    private static final int DATABASE_VERSION = 2;

    private static final String USERS_TABLE = "users";
    private static final String EVENTS_TABLE = "events";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Creates the users and events tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + USERS_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)";

        String createEventsTable = "CREATE TABLE " + EVENTS_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "name TEXT, " +
                "date TEXT, " +
                "time TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    /**
     * Rebuilds the database when the database version changes.
     * This is okay for class testing, but a real app would use migration logic.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE);
        onCreate(db);
    }

    /**
     * Adds a new user account.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(USERS_TABLE, null, values);

        return result != -1;
    }

    /**
     * Checks if a username already exists.
     */
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USERS_TABLE + " WHERE username = ?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();
        return exists;
    }

    /**
     * Checks if the username and password match an existing user.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USERS_TABLE + " WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        boolean userExists = cursor.getCount() > 0;

        cursor.close();
        return userExists;
    }

    /**
     * Returns the ID of the logged-in user.
     * This ID is used to connect events to the correct account.
     */
    public int getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM " + USERS_TABLE + " WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        cursor.close();
        return userId;
    }

    /**
     * Adds an event for one specific user.
     */
    public boolean addEvent(int userId, String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);

        long result = db.insert(EVENTS_TABLE, null, values);

        return result != -1;
    }

    /**
     * Gets only the events that belong to the logged-in user.
     */
    /**
     * Gets only the events that belong to the logged-in user.
     * Events are sorted by closest date first.
     */
    public Cursor getEventsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT id, name, date, time FROM " + EVENTS_TABLE +
                        " WHERE user_id = ? " +
                        " ORDER BY substr(date, 7, 4) || '-' || " +
                        "printf('%02d', CAST(substr(date, 1, instr(date, '/') - 1) AS INTEGER)) || '-' || " +
                        "printf('%02d', CAST(substr(date, instr(date, '/') + 1, " +
                        "instr(substr(date, instr(date, '/') + 1), '/') - 1) AS INTEGER)) ASC",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Updates an event only if it belongs to the logged-in user.
     */
    public boolean updateEvent(int eventId, int userId, String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("date", date);
        values.put("time", time);

        int rowsUpdated = db.update(
                EVENTS_TABLE,
                values,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(eventId), String.valueOf(userId)}
        );

        return rowsUpdated > 0;
    }

    /**
     * Deletes an event only if it belongs to the logged-in user.
     */
    public boolean deleteEvent(int eventId, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                EVENTS_TABLE,
                "id = ? AND user_id = ?",
                new String[]{String.valueOf(eventId), String.valueOf(userId)}
        );

        return rowsDeleted > 0;
    }
}